from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def index(request):
    return render(request,'index.html')
def patient(request):
    return render(request,'patient.html') 
def staff(request):
    return render(request,'staff.html')
def contact(request):
     return render(request,'contact.html')
#create your views here.


#views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required
from .forms import PatientForm #If you're using the PatientForm
from .forms import StaffForm  #If you're using the StaffForm

def admin_login(request):
    correct_username = 'nima'
    correct_password = '1234'

    # check if the request method is POST
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if username == correct_username and password == correct_password:
            return redirect('adashboard')
        else:
            return HttpResponse('Invalid credentials,please try again.')

    return render(request,'admin_login.html')

def adashboard(request):
    return render(request,'adashboard.html')

def alogin_view(request):
    if request.method == 'POST':
        email = request.POST['email']  
        password = request.POST['password']  
        user = authenticate(request,email=email,password=password)

        if user is not None:
            alogin(request,user)
            return redirect('dashboard') #Redirect to dashboard on successful login
        else:
            return render(request,'adashboard.html',{'error':'Invalid credentials'})

    return render(request,'admin_alogin.html')      

 
from django.shortcuts import render, redirect
from .forms import PatientForm

def register(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect after successful registration
        else:
            print(form.errors)  # This will print the form validation errors to the console
    else:
        form = PatientForm()  # Initialize the form for GET request
    
    return render(request, 'patientregister.html', {'form': form})

def login_view(request):
    if request.method == 'POST':
        email = request.POST['email']  
        password = request.POST['password']  
        user = authenticate(request,email=email,password=password)

        if user is not None:
            login(request,user)
            return redirect('dashboard') #Redirect to dashboard on successful login
        else:
            return render(request,'patient_login.html',{'error':'Invalid credentials'})

    return render(request,'patient_login.html')      

@login_required
def dashboard(request):
    return render(request,'dashboard.html') #only accessible to logged-in users  
        



def sregister_view(request):
    if request.method=='POST':
        form=StaffForm(request.POST) 
        if form.is_valid():
            form.save()  #save the staff data(password will be hashed automatically)
            return redirect('slogin')  #Redirect to login page after successful registration
    else:
        form=StaffForm()

    return render(request,'staff.html',{'form': form})    

def slogin_view(request):
    if request.method == 'POST':
        email = request.POST['email']  
        password = request.POST['password']  
        user = authenticate(request,email=email,password=password)

        if user is not None:
            slogin(request,user)
            return redirect('sdashboard') #Redirect to dashboard on successful login
        else:
            return render(request,'staff_login.html',{'error':'Invalid credentials'})

    return render(request,'staff_login.html')      

@login_required
def sdashboard_view(request):
    return render(request,'sdashboard.html') #only accessible to logged-in users  


from .models import Patient
def patient(request):
    patients =Patient.objects.all()

    return render(request,'patient.html', {'patients': patients})

def booking(request):
    return render(request,'booking.html')

def report(request):
    return render(request,'report.html')

def enquiry(request):
    return render(request,'enquiry.html')

def setting(request):
    return render(request,'setting.html')

def adminpatient(request):
    adminpatients =Patient.objects.all()
    return render(request,'adminPatient.html', {'Patient': adminpatients})

def appointment(request):
    return render(request,'appointment.html')

def adminreport(request):
    return render(request,'adminreport.html')

def adminsetting(request):
    return render(request,'adminsetting.html')

def profile(request):
    return render(request,'profile.html')
from django.shortcuts import render, get_object_or_404, redirect
from .models import Patient
from .forms import PatientForm  # Assuming you have a form for Patient

def edit_patient(request, id):
    patient = get_object_or_404(Patient, id=id)
    
    if request.method == 'POST':
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            return redirect('adminpatient')  # Redirect back to the patient list
    else:
        form = PatientForm(instance=patient)

    return render(request, 'edit_patient.html', {'form': form})
from django.shortcuts import get_object_or_404, redirect
from .models import Patient

def delete_patient(request, id):
    patient = get_object_or_404(Patient, id=id)
    patient.delete()
    return redirect('adminpatient')  # Redirect back to the patient list

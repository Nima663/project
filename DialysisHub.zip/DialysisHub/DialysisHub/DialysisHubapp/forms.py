from django import forms
from . models import Patient
from . models import Staff

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ['name','age','email','patient_id','password','phone_number','address']

class StaffForm(forms.ModelForm):
    class Meta:
        model = Staff
        fields = ['name','email','password','phone_number']

from django import forms
from .models import Patient


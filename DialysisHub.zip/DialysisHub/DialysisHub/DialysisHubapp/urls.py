from django.contrib import admin
from django.urls import path,include
from . import views
urlpatterns = [
    path('',views.index,name='index'),
   
    path('patients/',views.patient,name='patients'),
    path('staffs/',views.staff,name='staffs'),
    path('contacts/',views.contact,name='contacts'),
    path('register/',views.register,name='register'), #Register URL
    path('login/',views.login_view,name='login'), #Login URL
    path('login/dashboard/',views.dashboard,name='dashboard'),#Dashboard URL
    path('login/adashboard/',views.adashboard,name='adashboard'),#Dashboard URL

    
    path('sregister/',views.sregister_view,name='sregister'), #Register URL
    path('slogin/',views.slogin_view,name='slogin'), #Login URL
    path('adashboard/',views.adashboard,name='adashboard'),#Dashboard URL

    path('admin_login/',views.admin_login,name='admin_login'),
    path('alogin/',views.alogin_view,name='alogin'), #Login URL
    path('slogin/',views.slogin_view,name='slogin'), #Login URL 
    path('slogin/dashboard/',views.sdashboard_view,name='sdashboard'), #Login URL 
    path('patient/',views.patient,name='patient'),
    path('booking/',views.booking,name='booking'),
    path('report/',views.report,name='report'),
    path('enquiry/',views.enquiry,name='enquiry'),
    path('setting/',views.setting,name='setting'),
    path('adminpatient/',views.adminpatient,name='adminpatient'),
    path('appointment/',views.appointment,name='appointment'),
    path('adminreport/',views.adminreport,name='adminreport'),
    path('adminsetting/',views.adminsetting,name='adminsetting'),
    path('profile/',views.profile,name='profile'),
    path('edit_patient/<int:id>/', views.edit_patient, name='edit_patient'),
    path('delete_patient/<int:id>/', views.delete_patient, name='delete_patient'),
]